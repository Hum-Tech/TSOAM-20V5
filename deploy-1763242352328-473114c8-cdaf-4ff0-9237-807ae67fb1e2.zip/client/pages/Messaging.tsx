import { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Plus,
  Search,
  Download,
  MessageSquare,
  Mail,
  Send,
  Users,
  Clock,
  CheckCircle,
  AlertCircle,
  Filter,
  Bell,
  MessageCircle,
  Phone,
  UserCheck,
  Building,
  Heart,
  Music,
  Baby,
  Shield,
  BookOpen,
  Save,
} from "lucide-react";
import * as XLSX from "xlsx";
import { useAuth } from "@/contexts/AuthContext";

interface Message {
  id: string;
  type: "SMS" | "Email";
  recipient: string;
  recipientType: "Member" | "Employee" | "Group";
  subject?: string;
  message: string;
  status: "Sent" | "Pending" | "Failed" | "Delivered";
  sentDate: string;
  sentBy: string;
  recipientCount: number;
  deliveryRate?: number;
}

interface Contact {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  type: "Member" | "Employee";
  department?: string;
  serviceGroup?: string;
  isActive: boolean;
}

interface MessageTemplate {
  id: string;
  name: string;
  type: "SMS" | "Email";
  subject?: string;
  content: string;
  category: string;
}

// System contacts - integrating with member and employee databases
const getSystemContacts = (): Contact[] => {
  return [
    // Church Members
    {
      id: "M001",
      name: "John Doe",
      phone: "+254700123456",
      email: "john.doe@tsoam.com",
      type: "Member",
      serviceGroup: "Ushering Team",
      isActive: true,
    },
    {
      id: "M002",
      name: "Mary Wanjiku",
      phone: "+254700234567",
      email: "mary.wanjiku@tsoam.com",
      type: "Member",
      serviceGroup: "Choir",
      isActive: true,
    },
    {
      id: "M003",
      name: "Peter Kamau",
      phone: "+254700345678",
      email: "peter.kamau@tsoam.com",
      type: "Member",
      serviceGroup: "Youth Ministry",
      isActive: true,
    },
    {
      id: "M004",
      name: "Grace Muthoni",
      phone: "+254700456789",
      email: "grace.muthoni@tsoam.com",
      type: "Member",
      serviceGroup: "Women's Ministry",
      isActive: true,
    },
    {
      id: "M005",
      name: "David Kiprotich",
      phone: "+254700567890",
      email: "david.kiprotich@tsoam.com",
      type: "Member",
      serviceGroup: "Men's Ministry",
      isActive: true,
    },
    {
      id: "M006",
      name: "Sarah Njeri",
      phone: "+254700678901",
      email: "sarah.njeri@tsoam.com",
      type: "Member",
      serviceGroup: "Sunday School",
      isActive: true,
    },
    {
      id: "M007",
      name: "Michael Otieno",
      phone: "+254701789012",
      email: "michael.otieno@tsoam.com",
      type: "Member",
      serviceGroup: "Prayer Team",
      isActive: true,
    },
    {
      id: "M008",
      name: "Ruth Wanjala",
      phone: "+254702890123",
      email: "ruth.wanjala@tsoam.com",
      type: "Member",
      serviceGroup: "Children's Ministry",
      isActive: true,
    },
    // Church Staff/Employees
    {
      id: "E001",
      name: "Pastor James Kuria",
      phone: "+254700789012",
      email: "pastor.james@tsoam.com",
      type: "Employee",
      department: "Ministry Leadership",
      isActive: true,
    },
    {
      id: "E002",
      name: "Humphrey Njoroge",
      phone: "+254700890123",
      email: "admin@tsoam.com",
      type: "Employee",
      department: "Administration",
      isActive: true,
    },
    {
      id: "E003",
      name: "Finance Officer",
      phone: "+254700901234",
      email: "finance@tsoam.com",
      type: "Employee",
      department: "Finance",
      isActive: true,
    },
    {
      id: "E004",
      name: "HR Officer",
      phone: "+254701012345",
      email: "hr@tsoam.com",
      type: "Employee",
      department: "Human Resources",
      isActive: true,
    },
    {
      id: "E005",
      name: "Secretary",
      phone: "+254701123456",
      email: "secretary@tsoam.com",
      type: "Employee",
      department: "Administration",
      isActive: true,
    },
  ];
};

// Service groups for filtering
const SERVICE_GROUPS = [
  "Choir",
  "Ushering Team",
  "Youth Ministry",
  "Women's Ministry",
  "Men's Ministry",
  "Sunday School",
  "Prayer Team",
  "Children's Ministry",
  "Evangelism Team",
  "Welfare Committee",
];

const DEPARTMENTS = [
  "Ministry Leadership",
  "Administration",
  "Finance",
  "Human Resources",
  "Security",
];

// Message templates
const messageTemplates: MessageTemplate[] = [
  {
    id: "T001",
    name: "Sunday Service Reminder",
    type: "SMS",
    content:
      "Reminder: Sunday service starts at 9:00 AM. Join us for worship and fellowship at TSOAM Church. God bless!",
    category: "Service Reminders",
  },
  {
    id: "T002",
    name: "Welcome New Member",
    type: "Email",
    subject: "Welcome to TSOAM Church Family",
    content:
      "Dear [NAME], Welcome to The Seed of Abraham Ministry (TSOAM) Church International! We're excited to have you join our church family. We look forward to growing together in faith and fellowship.",
    category: "Welcome Messages",
  },
  {
    id: "T003",
    name: "Midweek Service",
    type: "SMS",
    content:
      "Join us for midweek service this Wednesday at 6:00 PM. Topic: [TOPIC]. Venue: Main sanctuary. See you there!",
    category: "Service Reminders",
  },
  {
    id: "T004",
    name: "Tithe Reminder",
    type: "SMS",
    content:
      "Dear [NAME], remember that tithing is an act of worship and obedience. Your faithfulness in giving helps support God's work at TSOAM.",
    category: "Stewardship",
  },
  {
    id: "T005",
    name: "Prayer Request",
    type: "SMS",
    content:
      "TSOAM Prayer Chain: Please join us in prayer for [REQUEST]. Let's stand together in faith and intercession.",
    category: "Prayer & Spiritual",
  },
  {
    id: "T006",
    name: "Event Announcement",
    type: "Email",
    subject: "[EVENT] - TSOAM Church",
    content:
      "Dear Church Family, We're excited to announce [EVENT] on [DATE] at [TIME]. Location: [VENUE]. For more information, contact the church office at admin@tsoam.com.",
    category: "Events & Announcements",
  },
];

// Mock message history
const mockMessages: Message[] = [
  {
    id: "MSG-2025-001",
    type: "SMS",
    recipient: "All Members",
    recipientType: "Group",
    message:
      "Reminder: Sunday service starts at 9:00 AM. Join us for worship and fellowship at TSOAM Church. God bless!",
    status: "Delivered",
    sentDate: "2025-01-16 08:00",
    sentBy: "Admin",
    recipientCount: 1247,
    deliveryRate: 98.5,
  },
  {
    id: "MSG-2025-002",
    type: "Email",
    recipient: "All Staff",
    recipientType: "Group",
    subject: "Monthly Staff Meeting - TSOAM",
    message:
      "Dear Team, Please join us for the monthly staff meeting on Friday at 2:00 PM in the conference room. Agenda will cover ministry updates and upcoming events.",
    status: "Sent",
    sentDate: "2025-01-15 14:30",
    sentBy: "HR Officer",
    recipientCount: 20,
    deliveryRate: 100,
  },
  {
    id: "MSG-2025-003",
    type: "SMS",
    recipient: "Youth Ministry",
    recipientType: "Group",
    message:
      "Youth Bible study tonight at 6:00 PM. Topic: Living with Purpose. Main hall. See you there!",
    status: "Delivered",
    sentDate: "2025-01-15 16:00",
    sentBy: "Youth Leader",
    recipientCount: 85,
    deliveryRate: 97.6,
  },
  {
    id: "MSG-2025-004",
    type: "Email",
    recipient: "Mary Wanjiku",
    recipientType: "Member",
    subject: "Welcome to TSOAM Church Family",
    message:
      "Dear Mary, Welcome to The Seed of Abraham Ministry! We're excited to have you join our church family. We look forward to growing together in faith.",
    status: "Delivered",
    sentDate: "2025-01-14 10:00",
    sentBy: "Pastor James",
    recipientCount: 1,
    deliveryRate: 100,
  },
];

export default function Messaging() {
  const { user } = useAuth();

  // Role-based access check - Admin, HR Officer, Finance Officer, User, and Pastor can send messages
  const canSendMessages = user?.role?.toLowerCase() === "admin" ||
                         user?.role?.toLowerCase() === "pastor" ||
                         user?.role?.toLowerCase() === "hr" ||
                         user?.role?.toLowerCase() === "finance" ||
                         user?.role?.toLowerCase() === "user";


  const [searchTerm, setSearchTerm] = useState("");
  const [contacts] = useState<Contact[]>(getSystemContacts());
  const [messages, setMessages] = useState<Message[]>(() => {
    // Load messages including user's sent in-app messages
    const senderKey = `sent_messages_${user?.id}`;
    const sentMessages = JSON.parse(localStorage.getItem(senderKey) || '[]');
    // Combine with mock messages, ensuring proper format
    const formattedSentMessages = sentMessages.map((msg: any) => ({
      id: msg.id,
      type: msg.type || "Internal Message",
      recipient: msg.recipient,
      recipientType: msg.recipientType || "Employee",
      subject: msg.subject,
      message: msg.message,
      status: msg.status || "Sent",
      sentDate: msg.sentDate,
      sentBy: msg.sentBy,
      recipientCount: msg.recipientCount || 1,
      deliveryRate: msg.deliveryRate || 100,
      deliveryMethod: msg.deliveryMethod || "In-App Notification"
    }));
    return [...formattedSentMessages, ...mockMessages];
  });
  const [templates] = useState<MessageTemplate[]>(messageTemplates);
  const [selectedMessages, setSelectedMessages] = useState<string[]>([]);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  // Function to refresh message history
  const refreshMessageHistory = () => {
    const senderKey = `sent_messages_${user?.id}`;
    const sentMessages = JSON.parse(localStorage.getItem(senderKey) || '[]');
    const formattedSentMessages = sentMessages.map((msg: any) => ({
      id: msg.id,
      type: msg.type || "Internal Message",
      recipient: msg.recipient,
      recipientType: msg.recipientType || "Employee",
      subject: msg.subject,
      message: msg.message,
      status: msg.status || "Sent",
      sentDate: msg.sentDate,
      sentBy: msg.sentBy,
      recipientCount: msg.recipientCount || 1,
      deliveryRate: msg.deliveryRate || 100,
      deliveryMethod: msg.deliveryMethod || "In-App Notification"
    }));
    setMessages([...formattedSentMessages, ...mockMessages]);
  };

  // Dialog states
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [isContactsOpen, setIsContactsOpen] = useState(false);

  // Message composition
  const [selectedContacts, setSelectedContacts] = useState<string[]>([]);
  const [messageType, setMessageType] = useState<"SMS" | "Email">("SMS");
  const [recipientFilter, setRecipientFilter] = useState("all");
  const [groupFilter, setGroupFilter] = useState("all");
  const [messageContent, setMessageContent] = useState("");
  const [subject, setSubject] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");

  // Filters
  const [filterType, setFilterType] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [contactFilter, setContactFilter] = useState("all");
  const [serviceGroupFilter, setServiceGroupFilter] = useState("all");

  // Calculate stats
  const totalMessages = messages.length;
  const sentToday = messages.filter((m) =>
    m.sentDate.includes(new Date().toISOString().split("T")[0]),
  ).length;
  const avgDeliveryRate =
    messages.reduce((acc, msg) => acc + (msg.deliveryRate || 0), 0) /
    messages.length;
  const totalContacts = contacts.filter((c) => c.isActive).length;

  // Filter contacts based on current filters
  const filteredContacts = contacts.filter((contact) => {
    const matchesSearch =
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.phone?.includes(searchTerm) ||
      contact.email?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType =
      contactFilter === "all" || contact.type.toLowerCase() === contactFilter;
    const matchesGroup =
      serviceGroupFilter === "all" ||
      contact.serviceGroup === serviceGroupFilter ||
      contact.department === serviceGroupFilter;

    const hasValidContact =
      messageType === "SMS" ? contact.phone : contact.email;

    return (
      matchesSearch &&
      matchesType &&
      matchesGroup &&
      hasValidContact &&
      contact.isActive
    );
  });

  // Filter messages
  const filteredMessages = messages.filter((message) => {
    const matchesSearch =
      message.recipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.message.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "All" || message.type === filterType;
    const matchesStatus =
      filterStatus === "All" || message.status === filterStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const handleSelectAllContacts = (checked: boolean) => {
    if (checked) {
      setSelectedContacts(filteredContacts.map((c) => c.id));
    } else {
      setSelectedContacts([]);
    }
  };

  const handleContactSelect = (contactId: string, checked: boolean) => {
    if (checked) {
      setSelectedContacts([...selectedContacts, contactId]);
    } else {
      setSelectedContacts(selectedContacts.filter((id) => id !== contactId));
    }
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find((t) => t.id === templateId);
    if (template) {
      setMessageContent(template.content);
      if (template.subject) {
        setSubject(template.subject);
      }
      if (template.type !== messageType) {
        setMessageType(template.type);
      }
    }
  };

  const sendMessage = async () => {
    // Check permissions
    if (!canSendMessages) {
      alert("You don't have permission to send messages. Contact your administrator.");
      return;
    }

    if (!messageContent || selectedContacts.length === 0) {
      alert("Please select recipients and enter a message");
      return;
    }

    // Create new message
    const newMessage: Message = {
      id: `MSG-2025-${(messages.length + 1).toString().padStart(3, "0")}`,
      type: messageType,
      recipient:
        selectedContacts.length === 1
          ? contacts.find((c) => c.id === selectedContacts[0])?.name ||
            "Unknown"
          : `${selectedContacts.length} recipients`,
      recipientType: selectedContacts.length === 1 ? "Member" : "Group",
      subject: messageType === "Email" ? subject : undefined,
      message: messageContent,
      status: "Sent",
      sentDate: new Date().toISOString().replace("T", " ").substring(0, 16),
      sentBy: user?.name || "Admin",
      recipientCount: selectedContacts.length,
      deliveryRate: 100,
    };

    // Handle message delivery based on recipient type
    const selectedContactsList = contacts.filter(c => selectedContacts.includes(c.id));
    const isPublicMessage = recipientFilter === "all" || selectedContacts.length > 10;

    // Separate employees and members
    const employeeContacts = selectedContactsList.filter(c => c.type === "Employee");
    const memberContacts = selectedContactsList.filter(c => c.type === "Member");

    // For employees: Create in-app notifications (they shouldn't receive SMS/Email)
    if (employeeContacts.length > 0) {
      employeeContacts.forEach(contact => {
        // Create in-app notification for employee
        const notification = {
          id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          title: messageType === "Email" ? (subject || "New Internal Message") : "New Internal Message",
          message: messageContent.length > 100 ? messageContent.substring(0, 100) + "..." : messageContent,
          fullMessage: messageContent, // Store full message content
          sender: user?.name || "System",
          senderId: user?.id || "system",
          recipient: contact.name,
          recipientId: contact.id,
          recipientEmail: contact.email, // Add email for better matching
          type: "internal",
          isPublic: false,
          timestamp: new Date().toISOString(),
          read: false,
          deliveryMethod: "notification",
          messageType: messageType,
          subject: messageType === "Email" ? subject : undefined
        };

        // Store notification in localStorage with user-specific key for better targeting
        const userSpecificKey = `notifications_${contact.id}`;
        const existingNotifications = JSON.parse(localStorage.getItem(userSpecificKey) || '[]');
        existingNotifications.unshift(notification);
        localStorage.setItem(userSpecificKey, JSON.stringify(existingNotifications));

        // Also store in general notifications for backward compatibility
        const existingGeneralNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
        existingGeneralNotifications.unshift(notification);
        localStorage.setItem('notifications', JSON.stringify(existingGeneralNotifications));

        // Create a sent message record for sender's history
        const sentMessageRecord = {
          id: `sent-${Date.now()}-${contact.id}-${Math.random().toString(36).substr(2, 9)}`,
          type: "Internal Message",
          recipient: contact.name,
          recipientType: "Employee",
          recipientId: contact.id,
          subject: messageType === "Email" ? subject : undefined,
          message: messageContent,
          status: "Sent",
          sentDate: new Date().toISOString().replace("T", " ").substring(0, 16),
          sentBy: user?.name || "Admin",
          recipientCount: 1,
          deliveryRate: 100,
          deliveryMethod: "In-App Notification",
          originalNotificationId: notification.id
        };

        // Store in sender's sent messages
        const senderKey = `sent_messages_${user?.id}`;
        const senderMessages = JSON.parse(localStorage.getItem(senderKey) || '[]');
        senderMessages.unshift(sentMessageRecord);
        localStorage.setItem(senderKey, JSON.stringify(senderMessages));
      });

      // Dispatch event to update notification bell in header for employees
      employeeContacts.forEach(contact => {
        window.dispatchEvent(new CustomEvent('notificationAdded', {
          detail: {
            count: 1,
            type: "Internal",
            sender: user?.name,
            recipient: contact.name,
            recipientId: contact.id
          }
        }));
      });
    }

    // For members: Continue with SMS/Email delivery
    if (memberContacts.length > 0 && !isPublicMessage) {
      memberContacts.forEach(contact => {
        // Create delivery record for member (SMS/Email will be sent)
        const deliveryRecord = {
          id: `delivery-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          contactId: contact.id,
          contactName: contact.name,
          contactType: contact.type,
          messageType: messageType,
          content: messageContent,
          subject: messageType === "Email" ? subject : undefined,
          deliveryMethod: messageType === "SMS" ? contact.phone : contact.email,
          timestamp: new Date().toISOString(),
          status: "sent"
        };

        // Store delivery record
        const deliveryRecords = JSON.parse(localStorage.getItem('messageDeliveries') || '[]');
        deliveryRecords.unshift(deliveryRecord);
        localStorage.setItem('messageDeliveries', JSON.stringify(deliveryRecords));
      });

      console.log(`📱 ${messageType} sent to ${memberContacts.length} member(s) via ${messageType === "SMS" ? "phone" : "email"}`);
    }

    try {
      // Always add to local state first
      setMessages((prev) => [newMessage, ...prev]);

      // Separate success handling for employees vs members
      const employeeCount = selectedContactsList.filter(c => c.type === "Employee").length;
      const memberCount = selectedContactsList.filter(c => c.type === "Member").length;

      let successMessage = "Message sent successfully!\n";
      let allSent = true;

      // For employees, in-app notifications are always successful if created
      if (employeeCount > 0) {
        successMessage += `• ${employeeCount} staff member(s) notified in-app ✓\n`;
      }

      // For members, attempt API call for SMS/Email
      if (memberCount > 0) {
        try {
          const response = await fetch("/api/messages", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              ...newMessage,
              sender_id: user?.id,
              recipient_ids: memberContacts.map(c => c.id),
              message_content: messageContent,
              message_type: messageType,
            }),
          });

          if (response.ok) {
            successMessage += `• ${memberCount} member(s) sent via ${messageType} ✓`;
          } else {
            successMessage += `• ${memberCount} member(s) via ${messageType} ⚠️ (API Error)`;
            allSent = false;
          }
        } catch (error) {
          successMessage += `• ${memberCount} member(s) via ${messageType} ⚠️ (Offline)`;
          allSent = false;
        }
      }

      // Log the activity
      try {
        await fetch("/api/system-logs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "Message Sent",
            module: "Messaging",
            details: `${messageType} sent to ${selectedContacts.length} recipient(s) (${employeeCount} in-app, ${memberCount} external): "${messageContent.substring(0, 50)}..."`,
            severity: allSent ? "Info" : "Warning",
          }),
        });
      } catch (logError) {
        console.log("Could not log activity (offline mode)");
      }

      alert(successMessage);

      // Refresh message history to show new sent messages
      refreshMessageHistory();
    } catch (error) {
      console.error("Failed to send message:", error);
      alert("Message processing failed. Please try again.");
    }

    // Reset form
    setSelectedContacts([]);
    setMessageContent("");
    setSubject("");
    setIsComposeOpen(false);
  };

  // Delete selected messages (privileged users only)
  const handleDeleteMessages = async () => {
    if (!user || !["Admin", "HR Officer"].includes(user.role)) {
      alert("You don't have permission to delete messages");
      return;
    }

    if (selectedMessages.length === 0) {
      alert("Please select messages to delete");
      return;
    }

    try {
      // Delete from backend
      const response = await fetch("/api/messages/delete", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message_ids: selectedMessages }),
      });

      if (response.ok) {
        // Remove from local state
        setMessages((prev) =>
          prev.filter((msg) => !selectedMessages.includes(msg.id)),
        );
        setSelectedMessages([]);
        setShowDeleteDialog(false);

        // Log the activity
        await fetch("/api/system-logs", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "Messages Deleted",
            module: "Messaging",
            details: `${selectedMessages.length} message(s) deleted by ${user.name}`,
            severity: "Warning",
          }),
        });

        alert(`${selectedMessages.length} message(s) deleted successfully`);
      } else {
        alert("Failed to delete messages. Please try again.");
      }
    } catch (error) {
      console.error("Failed to delete messages:", error);
      alert("Failed to delete messages. Please try again.");
    }
  };

  const exportContacts = () => {
    const exportData = filteredContacts.map((contact) => ({
      Name: contact.name,
      Phone: contact.phone || "N/A",
      Email: contact.email || "N/A",
      Type: contact.type,
      "Service Group/Department":
        contact.serviceGroup || contact.department || "N/A",
      Status: contact.isActive ? "Active" : "Inactive",
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Contacts");
    XLSX.writeFile(
      workbook,
      `TSOAM_Contacts_${new Date().toISOString().split("T")[0]}.xlsx`,
    );
  };

  const exportMessageHistory = () => {
    const exportData = filteredMessages.map((msg) => ({
      "Message ID": msg.id,
      Type: msg.type,
      Recipient: msg.recipient,
      "Subject/Message": msg.subject || msg.message.substring(0, 50) + "...",
      "Recipients Count": msg.recipientCount,
      Status: msg.status,
      "Delivery Rate": msg.deliveryRate ? `${msg.deliveryRate}%` : "N/A",
      "Sent Date": msg.sentDate,
      "Sent By": msg.sentBy,
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Messages");
    XLSX.writeFile(
      workbook,
      `TSOAM_Messages_${new Date().toISOString().split("T")[0]}.xlsx`,
    );
  };

  const getServiceGroupIcon = (group: string) => {
    switch (group) {
      case "Choir":
        return <Music className="h-4 w-4" />;
      case "Ushering Team":
        return <UserCheck className="h-4 w-4" />;
      case "Youth Ministry":
        return <Users className="h-4 w-4" />;
      case "Women's Ministry":
        return <Heart className="h-4 w-4" />;
      case "Children's Ministry":
        return <Baby className="h-4 w-4" />;
      case "Prayer Team":
        return <BookOpen className="h-4 w-4" />;
      default:
        return <Users className="h-4 w-4" />;
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Church Messaging</h1>
            <p className="text-muted-foreground">
              Send SMS and emails to church members and staff
            </p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isContactsOpen} onOpenChange={setIsContactsOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Users className="h-4 w-4 mr-2" />
                  View Contacts ({totalContacts})
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Church Contacts Directory</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {/* Contact Filters */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search contacts..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Select
                      value={contactFilter}
                      onValueChange={setContactFilter}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Contacts</SelectItem>
                        <SelectItem value="member">Members Only</SelectItem>
                        <SelectItem value="employee">Staff Only</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select
                      value={serviceGroupFilter}
                      onValueChange={setServiceGroupFilter}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Filter by group" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Groups</SelectItem>
                        {SERVICE_GROUPS.map((group) => (
                          <SelectItem key={group} value={group}>
                            {group}
                          </SelectItem>
                        ))}
                        {DEPARTMENTS.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button onClick={exportContacts} variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Export Contacts
                    </Button>
                  </div>

                  {/* Contacts Table */}
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Group/Department</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredContacts.map((contact) => (
                          <TableRow key={contact.id}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                {contact.serviceGroup &&
                                  getServiceGroupIcon(contact.serviceGroup)}
                                {contact.name}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Phone className="h-3 w-3" />
                                {contact.phone || "N/A"}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Mail className="h-3 w-3" />
                                {contact.email || "N/A"}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  contact.type === "Employee"
                                    ? "default"
                                    : "secondary"
                                }
                              >
                                {contact.type}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {contact.serviceGroup ||
                                contact.department ||
                                "N/A"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  <div className="text-sm text-muted-foreground">
                    Showing {filteredContacts.length} of {totalContacts}{" "}
                    contacts
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            {canSendMessages && (
              <Dialog open={isComposeOpen} onOpenChange={setIsComposeOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Compose Message
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Compose New Message</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  {/* Message Type */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Message Type</Label>
                      <Select
                        value={messageType}
                        onValueChange={(value: "SMS" | "Email") =>
                          setMessageType(value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="SMS">SMS</SelectItem>
                          <SelectItem value="Email">Email</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Use Template</Label>
                      <Select
                        value={selectedTemplate}
                        onValueChange={handleTemplateSelect}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choose template (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          {templates
                            .filter((t) => t.type === messageType)
                            .map((template) => (
                              <SelectItem key={template.id} value={template.id}>
                                {template.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Recipients Selection */}
                  <div>
                    <Label>Select Recipients</Label>
                    <div className="border rounded-lg p-4 max-h-60 overflow-y-auto">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="selectAll"
                            checked={
                              selectedContacts.length ===
                                filteredContacts.length &&
                              filteredContacts.length > 0
                            }
                            onCheckedChange={handleSelectAllContacts}
                          />
                          <Label htmlFor="selectAll">
                            Select All ({filteredContacts.length})
                          </Label>
                        </div>
                        <div className="flex gap-2">
                          <Select
                            value={contactFilter}
                            onValueChange={setContactFilter}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All</SelectItem>
                              <SelectItem value="member">Members</SelectItem>
                              <SelectItem value="employee">Staff</SelectItem>
                            </SelectContent>
                          </Select>
                          <Select
                            value={serviceGroupFilter}
                            onValueChange={setServiceGroupFilter}
                          >
                            <SelectTrigger className="w-40">
                              <SelectValue placeholder="Filter group" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Groups</SelectItem>
                              {SERVICE_GROUPS.map((group) => (
                                <SelectItem key={group} value={group}>
                                  {group}
                                </SelectItem>
                              ))}
                              {DEPARTMENTS.map((dept) => (
                                <SelectItem key={dept} value={dept}>
                                  {dept}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        {filteredContacts.map((contact) => (
                          <div
                            key={contact.id}
                            className="flex items-center space-x-2 p-2 border rounded"
                          >
                            <Checkbox
                              id={contact.id}
                              checked={selectedContacts.includes(contact.id)}
                              onCheckedChange={(checked) =>
                                handleContactSelect(contact.id, !!checked)
                              }
                            />
                            <Label
                              htmlFor={contact.id}
                              className="flex-1 cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                {contact.serviceGroup &&
                                  getServiceGroupIcon(contact.serviceGroup)}
                                <div>
                                  <div className="font-medium">
                                    {contact.name}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {messageType === "SMS"
                                      ? contact.phone
                                      : contact.email}{" "}
                                    • {contact.type}
                                    {contact.type === "Employee" && (
                                      <span className="ml-2 inline-flex items-center gap-1 text-blue-600">
                                        <Bell className="h-3 w-3" />
                                        <span className="text-xs">In-app notification</span>
                                      </span>
                                    )}
                                    {contact.type === "Member" && (
                                      <span className="ml-2 inline-flex items-center gap-1 text-green-600">
                                        {messageType === "SMS" ? <MessageSquare className="h-3 w-3" /> : <Mail className="h-3 w-3" />}
                                        <span className="text-xs">Via {messageType}</span>
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {selectedContacts.length} recipient(s) selected
                    </p>
                  </div>

                  {/* Message Content */}
                  {messageType === "Email" && (
                    <div>
                      <Label htmlFor="subject">Subject</Label>
                      <Input
                        id="subject"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        placeholder="Enter email subject"
                      />
                    </div>
                  )}

                  <div>
                    <Label htmlFor="message">
                      Message Content
                      {messageType === "SMS" && (
                        <span className="text-sm text-muted-foreground ml-2">
                          ({messageContent.length}/160 characters)
                        </span>
                      )}
                    </Label>
                    <Textarea
                      id="message"
                      value={messageContent}
                      onChange={(e) => setMessageContent(e.target.value)}
                      placeholder={
                        messageType === "SMS"
                          ? "Enter SMS message (max 160 characters)"
                          : "Enter email content"
                      }
                      rows={messageType === "SMS" ? 4 : 8}
                      maxLength={messageType === "SMS" ? 160 : undefined}
                    />
                  </div>

                  {/* Delivery Preview */}
                  {selectedContacts.length > 0 && (
                    <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                      <p className="text-sm font-medium text-blue-900 mb-2">Delivery Preview:</p>
                      {(() => {
                        const selectedContactsList = contacts.filter(c => selectedContacts.includes(c.id));
                        const employeeContacts = selectedContactsList.filter(c => c.type === "Employee");
                        const memberContacts = selectedContactsList.filter(c => c.type === "Member");

                        return (
                          <div className="space-y-1">
                            {employeeContacts.length > 0 && (
                              <div className="flex items-center gap-2 text-sm text-blue-700">
                                <Bell className="h-4 w-4" />
                                <span>{employeeContacts.length} staff member(s) will receive in-app notifications</span>
                              </div>
                            )}
                            {memberContacts.length > 0 && (
                              <div className="flex items-center gap-2 text-sm text-blue-700">
                                {messageType === "SMS" ? <MessageSquare className="h-4 w-4" /> : <Mail className="h-4 w-4" />}
                                <span>{memberContacts.length} member(s) will receive {messageType} to their {messageType === "SMS" ? "phone" : "email"}</span>
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </div>
                  )}

                  {/* Sender Information */}
                  <div className="bg-muted p-4 rounded-lg">
                    <p className="text-sm font-medium">Sender Information:</p>
                    <p className="text-sm text-muted-foreground">
                      {messageType === "SMS"
                        ? "SMS will be sent from: TSOAM Church (+254 700 123456)"
                        : "Email will be sent from: admin@tsoam.com"}
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={sendMessage}
                      disabled={
                        !messageContent || selectedContacts.length === 0
                      }
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Send {messageType} to {selectedContacts.length}{" "}
                      recipient(s)
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsComposeOpen(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            )}
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{totalMessages}</div>
                  <div className="text-sm text-muted-foreground">
                    Total Messages
                  </div>
                </div>
                <MessageSquare className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{sentToday}</div>
                  <div className="text-sm text-muted-foreground">
                    Sent Today
                  </div>
                </div>
                <Send className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">
                    {avgDeliveryRate.toFixed(1)}%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Delivery Rate
                  </div>
                </div>
                <CheckCircle className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{totalContacts}</div>
                  <div className="text-sm text-muted-foreground">
                    Active Contacts
                  </div>
                </div>
                <Users className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="messages" className="space-y-4">
          <TabsList>
            <TabsTrigger value="messages">Message History</TabsTrigger>
            <TabsTrigger value="templates">Message Templates</TabsTrigger>
            <TabsTrigger value="settings">SMS/Email Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle>Message History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search messages..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All">All Types</SelectItem>
                      <SelectItem value="SMS">SMS</SelectItem>
                      <SelectItem value="Email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All">All Status</SelectItem>
                      <SelectItem value="Sent">Sent</SelectItem>
                      <SelectItem value="Delivered">Delivered</SelectItem>
                      <SelectItem value="Failed">Failed</SelectItem>
                    </SelectContent>
                  </Select>
                  {user &&
                    ["Admin", "HR Officer"].includes(user.role) &&
                    selectedMessages.length > 0 && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => setShowDeleteDialog(true)}
                      >
                        Delete ({selectedMessages.length})
                      </Button>
                    )}
                  <Button variant="outline" onClick={exportMessageHistory}>
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      {user && ["Admin", "HR Officer"].includes(user.role) && (
                        <TableHead className="w-12">
                          <Checkbox
                            checked={
                              selectedMessages.length ===
                                filteredMessages.length &&
                              filteredMessages.length > 0
                            }
                            onCheckedChange={(checked) => {
                              if (checked) {
                                setSelectedMessages(
                                  filteredMessages.map((m) => m.id),
                                );
                              } else {
                                setSelectedMessages([]);
                              }
                            }}
                          />
                        </TableHead>
                      )}
                      <TableHead>Type</TableHead>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Subject/Message</TableHead>
                      <TableHead>Recipients</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Delivery Rate</TableHead>
                      <TableHead>Sent Date</TableHead>
                      <TableHead>Sent By</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMessages.map((message) => (
                      <TableRow key={message.id}>
                        {user &&
                          ["Admin", "HR Officer"].includes(user.role) && (
                            <TableCell>
                              <Checkbox
                                checked={selectedMessages.includes(message.id)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setSelectedMessages((prev) => [
                                      ...prev,
                                      message.id,
                                    ]);
                                  } else {
                                    setSelectedMessages((prev) =>
                                      prev.filter((id) => id !== message.id),
                                    );
                                  }
                                }}
                              />
                            </TableCell>
                          )}
                        <TableCell>
                          <Badge
                            variant={
                              message.type === "SMS" ? "default" : "secondary"
                            }
                          >
                            {message.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">
                          {message.recipient}
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <div>
                            {message.subject && (
                              <div className="font-medium text-sm">
                                {message.subject}
                              </div>
                            )}
                            <div className="text-sm text-muted-foreground truncate">
                              {message.message.substring(0, 60)}...
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{message.recipientCount}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              message.status === "Delivered"
                                ? "default"
                                : message.status === "Sent"
                                  ? "secondary"
                                  : message.status === "Failed"
                                    ? "destructive"
                                    : "outline"
                            }
                          >
                            {message.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {message.deliveryRate
                            ? `${message.deliveryRate}%`
                            : "N/A"}
                        </TableCell>
                        <TableCell>{message.sentDate}</TableCell>
                        <TableCell>{message.sentBy}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="templates">
            <Card>
              <CardHeader>
                <CardTitle>Message Templates</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {templates.map((template) => (
                    <Card key={template.id}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge
                                variant={
                                  template.type === "SMS"
                                    ? "default"
                                    : "secondary"
                                }
                              >
                                {template.type}
                              </Badge>
                              <span className="font-medium">
                                {template.name}
                              </span>
                              <Badge variant="outline">
                                {template.category}
                              </Badge>
                            </div>
                            {template.subject && (
                              <div className="text-sm font-medium mb-1">
                                Subject: {template.subject}
                              </div>
                            )}
                            <div className="text-sm text-muted-foreground">
                              {template.content}
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              handleTemplateSelect(template.id);
                              setIsComposeOpen(true);
                            }}
                          >
                            Use Template
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    SMS Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>SMS Gateway Provider</Label>
                    <Select defaultValue="safaricom">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="safaricom">
                          Safaricom (Recommended)
                        </SelectItem>
                        <SelectItem value="africastalking">
                          Africa's Talking
                        </SelectItem>
                        <SelectItem value="textmagic">TextMagic</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Sender ID</Label>
                    <Input
                      defaultValue="TSOAM"
                      placeholder="Church name or shortcode"
                    />
                  </div>
                  <div>
                    <Label>Default SMS Template Footer</Label>
                    <Textarea
                      defaultValue="- TSOAM Church International"
                      placeholder="Footer text to append to SMS"
                      rows={2}
                    />
                  </div>
                  <Button>
                    <Save className="h-4 w-4 mr-2" />
                    Save SMS Settings
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="h-5 w-5" />
                    Email Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>SMTP Server</Label>
                    <Input defaultValue="smtp.gmail.com" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Port</Label>
                      <Input defaultValue="587" />
                    </div>
                    <div>
                      <Label>Security</Label>
                      <Select defaultValue="tls">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="tls">TLS</SelectItem>
                          <SelectItem value="ssl">SSL</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>From Email</Label>
                    <Input defaultValue="admin@tsoam.com" />
                  </div>
                  <div>
                    <Label>From Name</Label>
                    <Input defaultValue="TSOAM Church International" />
                  </div>
                  <Button>
                    <Save className="h-4 w-4 mr-2" />
                    Save Email Settings
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Delete Messages Dialog */}
        <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-red-500" />
                Delete Messages
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
                <p className="text-sm text-red-700">
                  Are you sure you want to delete {selectedMessages.length}{" "}
                  selected message(s)? This action cannot be undone and will
                  permanently remove the message history.
                </p>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setShowDeleteDialog(false)}
                >
                  Cancel
                </Button>
                <Button variant="destructive" onClick={handleDeleteMessages}>
                  Delete Messages
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
